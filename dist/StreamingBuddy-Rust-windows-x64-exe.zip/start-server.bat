@echo off
cd /d "%~dp0"
REM Optional: set a strong master key so encrypted secrets are recoverable
REM set STREAMING_BUDDY_MASTER_KEY=change-this-to-a-long-random-secret
streaming_buddy_rs.exe server --host 127.0.0.1 --port 8811
pause
